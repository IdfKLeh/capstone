using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EventStageCanvas : MonoBehaviour
{
    public PopUpWindow popUpWindow;
    public GameObject eventStageDialogue;
    public GameObject eventImageGroup;
    public GameObject oneButtonGroup;
    public GameObject twoButtonGroup;
    public GameObject threeButtonGroup;
    public GameObject fourButtonGroup;

}
