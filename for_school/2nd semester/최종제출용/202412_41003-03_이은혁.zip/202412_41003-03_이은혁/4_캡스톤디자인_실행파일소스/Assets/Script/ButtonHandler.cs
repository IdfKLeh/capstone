using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonHandler : MonoBehaviour
{
    Button button;
    public string targetScene;
    //ButtonController buttonController;

    public void OnButtonClick_SceneChange(){
        //buttonController.sceneChange(targetScene);
    }
}
