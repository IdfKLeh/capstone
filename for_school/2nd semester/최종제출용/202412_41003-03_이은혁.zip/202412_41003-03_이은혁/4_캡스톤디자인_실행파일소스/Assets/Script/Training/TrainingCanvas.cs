using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class TrainingCanvas : MonoBehaviour
{
    //Training Scene에 존재하는 object들의 Serialization을 위한 스크립트
    public PopUpWindow popUpWindow;
    public Button mainMenuButton;
}
