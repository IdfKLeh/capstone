using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PopUpWindow : MonoBehaviour
{
   public Button yesButton;
   public Button noButton;
   public TextMeshProUGUI messageText;
}
