using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class MainPlayCanvas : MonoBehaviour
{
    public PopUpWindow popUpWindow;
    public GameObject mainStuff;
    public GameObject trainingStuff;
    public Image clickDetector;
}
