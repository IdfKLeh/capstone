using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BattleStageCanvas : MonoBehaviour
{
    public GameObject content;
    public GameObject buttonGroup;
    public GameObject winLossPanel;
}
